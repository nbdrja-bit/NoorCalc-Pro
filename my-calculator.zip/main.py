from kivy.app import App
from kivy.uix.boxlayout import BoxLayout
from kivy.uix.gridlayout import GridLayout
from kivy.uix.button import Button
from kivy.uix.textinput import TextInput
from kivy.uix.scrollview import ScrollView
from kivy.uix.label import Label
from kivy.core.window import Window
import math

Window.clearcolor = (0.05, 0.05, 0.05, 1)  # خلفية داكنة للآلة

class NoorCalc(App):
    def build(self):
        self.history = []

        main_layout = BoxLayout(orientation="vertical", padding=10, spacing=10)

        # ===== شاشة العرض =====
        self.display = TextInput(
            hint_text="0",
            multiline=False,
            font_size=70,
            background_color=(0,0,0,1),
            foreground_color=(1,1,1,1),
            halign="right",
            size_hint_y=None,
            height=140
        )
        main_layout.add_widget(self.display)

        # ===== النتيجة =====
        self.result_label = Label(
            text="Result",
            font_size=30,
            color=(0,1,0,1),
            size_hint_y=None,
            height=60
        )
        main_layout.add_widget(self.result_label)

        # ===== أزرار الأرقام والعمليات =====
        button_colors = {
            "num": (0.15,0.15,0.15,1),
            "op": (0.8,0.5,0,1),
            "func": (0.2,0.2,0.5,1)
        }

        buttons = [
            ["7","8","9","/"],
            ["4","5","6","*"],
            ["1","2","3","-"],
            ["0",".","=","+"],
        ]
        grid = GridLayout(cols=4, spacing=5, size_hint_y=None, height=400)
        for row in buttons:
            for item in row:
                color = button_colors["num"] if item.isdigit() or item == "." else button_colors["op"]
                btn = Button(
                    text=item,
                    font_size=38,
                    background_color=color,
                    color=(1,1,1,1)
                )
                btn.bind(on_press=self.on_press)
                grid.add_widget(btn)
        main_layout.add_widget(grid)

        # ===== أزرار إضافية ودوال علمية =====
        extra_buttons = [
            ("AC", self.clear),
            ("⌫", self.backspace),
            ("%", self.percent),
            ("^", self.power),
            ("√", self.sqrt),
            ("x²", self.square),
            ("sin", self.sin),
            ("cos", self.cos),
            ("tan", self.tan),
            ("log", self.log),
        ]
        extra_grid = GridLayout(cols=4, spacing=5, size_hint_y=None, height=280)
        for text, func in extra_buttons:
            color = button_colors["func"] if text not in ["AC","⌫","%","^"] else button_colors["op"]
            btn = Button(
                text=text,
                font_size=28,
                background_color=color,
                color=(1,1,1,1)
            )
            btn.bind(on_press=func)
            extra_grid.add_widget(btn)
        main_layout.add_widget(extra_grid)

        # ===== History =====
        self.history_label = Label(
            text="History:\n",
            size_hint_y=None,
            font_size=22,
            color=(1,1,1,1)
        )
        scroll = ScrollView(size_hint=(1, 1))
        scroll.add_widget(self.history_label)
        main_layout.add_widget(scroll)

        # ===== Keyboard =====
        Window.bind(on_key_down=self.on_key_down)

        return main_layout

    # ===== زرار الضغط =====
    def on_press(self, btn):
        if btn.text == "=":
            self.calculate()
        else:
            self.display.text += btn.text

    # ===== الحساب =====
    def calculate(self):
        try:
            exp = self.display.text.replace("^", "**")
            allowed = {
                "sqrt": math.sqrt,
                "sin": math.sin,
                "cos": math.cos,
                "tan": math.tan,
                "log": math.log,
            }
            result = eval(exp, {"__builtins__":None}, allowed)
            full = f"{self.display.text} = {result}"
            self.result_label.text = full
            self.history.append(full)
            self.update_history()
        except:
            self.result_label.text = "Error"

    # ===== دوال إضافية =====
    def clear(self, x):
        self.display.text = ""
        self.result_label.text = "Result"

    def backspace(self, x):
        if len(self.display.text) > 0:
            self.display.text = self.display.text[:-1]

    def percent(self, x):
        try:
            val = float(self.display.text)
            res = val / 100
            self.result_label.text = f"{val}% = {res}"
        except:
            self.result_label.text = "Error"

    def sqrt(self, x):
        self.display.text = f"sqrt({self.display.text})"

    def square(self, x):
        self.display.text = f"({self.display.text})**2"

    def power(self, x):
        self.display.text += "^"

    def sin(self, x):
        self.display.text = f"sin({self.display.text})"

    def cos(self, x):
        self.display.text = f"cos({self.display.text})"

    def tan(self, x):
        self.display.text = f"tan({self.display.text})"

    def log(self, x):
        self.display.text = f"log({self.display.text})"

    # ===== تحديث History =====
    def update_history(self):
        self.history_label.text = "History:\n" + "\n".join(self.history[-10:])

    # ===== Keyboard =====
    def on_key_down(self, window, key, scancode, codepoint, modifiers):
        if codepoint and codepoint.isdigit():
            self.display.text += codepoint
        elif codepoint in ['+', '-', '*', '/', '.']:
            self.display.text += codepoint
        elif codepoint == '^':
            self.display.text += "^"
        elif key in (13, 271):  # Enter = يساوي
            self.calculate()
        elif key == 8:  # Backspace
            if len(self.display.text) > 0:
                self.display.text = self.display.text[:-1]
        elif key == 27:  # ESC
            self.clear(None)
        return True

if __name__ == "__main__":
    NoorCalc().run()